<?php

class mysqlconex {
    public function conex() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "classmark";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Crear base de datos si no existe
        $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
        if ($conn->query($sql) === TRUE) {
            echo "Base de datos creada exitosamente o ya existe<br>";
        } else {
            echo "Error al crear la base de datos: " . $conn->error . "<br>";
        }

        // Seleccionar la base de datos
        $conn->select_db($dbname);

        // Crear tablas si no existen  
        $sql = "
        /*Fichas*/
        CREATE TABLE IF NOT EXISTS fichas (
            id_ficha INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
            numero_ficha INT(20),
            contraseña_ficha TEXT
        );

        /*Instructor*/
        CREATE TABLE IF NOT EXISTS instructor (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            nombre_instructor VARCHAR(50),
            numero_documento INT,
            contraseña_instructor VARCHAR(50)
        );

        /*Administrador*/
        CREATE TABLE IF NOT EXISTS administradores (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            codigo_admin VARCHAR(50),
            contraseña_admin VARCHAR(50)
        );
        ";

        if ($conn->multi_query($sql) === TRUE) {
            echo "Tablas creadas exitosamente o ya existen<br>";
        } else {
            echo "Error al crear las tablas: " . $conn->error . "<br>";
        }

        // Cerrar conexión
        $conn->close();
    }
}

// Crear una instancia de la clase y llamar al método conex
$conexion = new mysqlconex();
$conexion->conex();

?>