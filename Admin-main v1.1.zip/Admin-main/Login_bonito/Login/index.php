

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>

    <br>
    <main>
        <!-- Seleccionar tipo de cuenta -->
        <div class="container">
            <div class="log1">
                <center>
                <div class="bloque1">
                    Bienvenido
                </div>
                <div class="bloque2" >
                    Selecciona tu tipo de cuenta 
                </div>
                <div class="bloque3">
                    <div class="botones">
                        <button class="boton1" onclick="cambiarContenido()">
                            <i class="bi bi-backpack2-fill"></i>
                        </button>
                        <button class="boton2" onclick="cambiarContenido2()">
                            <i class="bi bi-book-fill"></i>
                        </button>
                        <button class="boton3" onclick="cambiarContenido3()">
                            <i class="bi bi-person-workspace"></i>
                        </button>     
                    </div>
                </div>
            </div>
        <!-- Aqui aparecen los formularios -->
            <div class="log2" id="Formularios">
                <!-- Formulario para los aprendizes -->
                <div id="FormularioAprendices"  >
                <div class="caja1">
                    Ficha
                </div>

                <div class="Formulario">
                    <form action="php/validar_o_registrar.php" method="post">
                        <div class="caja2">
                            <div>
                                <label for="numero_ficha" ></label><input class="input" type="number" name="numero_ficha" id="numero_ficha" placeholder="Numero ficha">
                            </div>

                            <div>
                                <label for="contraseña_ficha"></label><input class="input" type="text" name="contraseña_ficha" id="contraseña_ficha" placeholder="Contraseña ficha">
                            </div>
                        </div>

                        <div class="caja3">
                            <input class="registrar" type="submit" name="accion" value="Iniciar Sesión">
                            <input class="registrar" type="submit" name="accion" value="Registrar Ficha">
                        </div>

                    </form>
                </div>    
            </div>
            <!-- Formulario de los Admins -->
            <div id="ADMINS" class="OCULTO">
                <div id="FormularioAdministradores">
                    <div class="caja1">
                      Admin
                    </div>

                <div class="Formulario">
                    <form action="php/validar_o_registrar3.php" method="post">
                        <div class="caja2">
                            <div>
                                <label for="codigo_admin" ></label><input class="input" type="text" name="codigo_admin" id="codigo_admin" placeholder="Codigo Admin">
                            </div>

                            <div>
                                <label for="contraseña_admin"></label><input class="input" type="text" name="contraseña_admin" id="contraseña_admin" placeholder="Contraseña admin">
                            </div>
                        </div>

                    <div class="caja3">
                        <input class="registrar" type="submit" name="accion" value="Iniciar Sesión">
                        <input class="registrar" type="submit" name="accion" value="Registrar Admin">
                    </div>

                    </form>
                </div>    

            </div>
            
            <!-- Formularios para los instructores -->
            <div id="INSTRUCTOR" class="OCULTO">
                <div id="FormularioInstructores" >
                    <div class="caja1">
                       Instructor
                    </div>
 
                    <div class="Formulario">
                        <form action="php/validar_o_registrar2.php" method="post">
                            <div class="caja2">
                                <div>
                                    <label for="nombre_instructor" ></label><input class="input" type="text" name="nombre_instructor" id="nombre_instructor" placeholder="Nombre instructor">
                                </div>
               
                                <div>
                                    <label for="numero_documento"></label><input class="input" type="text" name="numero_documento" id="numero_documento" placeholder="Numero documento">
                                </div>
               
                                <div>
                                    <label for="contraseña_instructor"></label><input class="input" type="text" name="contraseña_instructor" id="contraseña_instructor" placeholder="Contraseña instructor">
                                </div>
                            </div>

                            <div class="caja3">
                                <input class="registrar" type="submit" name="accion" value="Iniciar Sesión">
                                <input class="registrar" type="submit" name="accion" value="Registrar Instructor">
                            </div>
        
                        </form>
                    </div>    
                </div>
            </div>
        </div>
    </main>
    <script src="script.js"></script>
</body>
</html>

