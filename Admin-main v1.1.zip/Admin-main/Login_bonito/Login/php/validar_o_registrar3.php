<?php
include("conexion.php");
$getmysql = new mysqlconex();
$getconex = $getmysql->conex();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_admin = $_POST["codigo_admin"];
    $contraseña_admin = $_POST["contraseña_admin"];

    // Validación en PHP para asegurarse de que los campos no están vacíos
    if (empty($codigo_admin) || empty($contraseña_admin)) {
        echo "<script> alert('Por favor, completa todos los campos.'); location.href='../registro.php'; </script>";
        exit();
    }

    // Consulta para verificar si ya existe el número de admin
    $consulta = "SELECT * FROM administradores WHERE codigo_admin = ?";
    $sentencia = mysqli_prepare($getconex, $consulta);
    mysqli_stmt_bind_param($sentencia, "s", $codigo_admin);
    mysqli_stmt_execute($sentencia);
    mysqli_stmt_store_result($sentencia);
    
    // Verificar qué botón fue presionado
    if ($_POST['accion'] == "Iniciar Sesión") {

        // Validar Inicio de sesión
        $consulta = "SELECT * FROM administradores WHERE codigo_admin = ? AND contraseña_admin = ?";
        $sentencia = mysqli_prepare($getconex, $consulta);
        mysqli_stmt_bind_param($sentencia, "ss", $codigo_admin, $contraseña_admin);
        mysqli_stmt_execute($sentencia);
        mysqli_stmt_store_result($sentencia);

        if (mysqli_stmt_num_rows($sentencia) > 0) {
            header("location:Admin/index.html");
        } else {
            header("location:e.html");
        }

        mysqli_stmt_close($sentencia);

    } elseif ($_POST['accion'] == "Registrar Admin") {

        // Validar Registro
        $consulta = "SELECT * FROM administradores WHERE codigo_admin = ?";
        $sentencia = mysqli_prepare($getconex, $consulta);
        mysqli_stmt_bind_param($sentencia, "s", $codigo_admin);
        mysqli_stmt_execute($sentencia);
        mysqli_stmt_store_result($sentencia);

        if (mysqli_stmt_num_rows($sentencia) > 0) {
            echo "<script> alert('El número de admin ya está registrado.'); location.href='../index.php'; </script>";
        } else {
            $query = "INSERT INTO administradores (codigo_admin, contraseña_admin) VALUES (?, ?)";
            $sentencia_insert = mysqli_prepare($getconex, $query);
            mysqli_stmt_bind_param($sentencia_insert, "ss", $codigo_admin, $contraseña_admin);
            mysqli_stmt_execute($sentencia_insert);

            if (mysqli_stmt_affected_rows($sentencia_insert) == 1) {
                echo "<script> alert('Admin registrado con éxito.'); location.href='../index.php'; </script>";
            } else {
                echo "<script> alert('Error al registrar el admin.'); location.href='../index.php'; </script>";
            }

            mysqli_stmt_close($sentencia_insert);
        }

        mysqli_stmt_close($sentencia);
    }

    mysqli_close($getconex);
}
?>
