<?php
include("conexion.php");
$getmysql = new mysqlconex();
$getconex = $getmysql->conex();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero_ficha = $_POST["numero_ficha"];
    $contraseña_ficha = $_POST["contraseña_ficha"];

    // Validación en PHP para asegurarse de que los campos no están vacíos
    if (empty($numero_ficha) || empty($contraseña_ficha)) {
        echo "<script> alert('Por favor, completa todos los campos.'); location.href='../registro.php'; </script>";
        exit();
    }

    // Consulta para verificar si ya existe el número de ficha
    $consulta = "SELECT * FROM fichas WHERE numero_ficha = ?";
    $sentencia = mysqli_prepare($getconex, $consulta);
    mysqli_stmt_bind_param($sentencia, "s", $numero_ficha);
    mysqli_stmt_execute($sentencia);
    mysqli_stmt_store_result($sentencia);
    
    // Verificar qué botón fue presionado
    if ($_POST['accion'] == "Iniciar Sesión") {

   // Validar Inicio de sesion
        $consulta = "SELECT * FROM fichas WHERE numero_ficha = ? AND contraseña_ficha = ?";
        $sentencia = mysqli_prepare($getconex, $consulta);
        mysqli_stmt_bind_param($sentencia, "ss", $numero_ficha, $contraseña_ficha);
        mysqli_stmt_execute($sentencia);
        mysqli_stmt_store_result($sentencia);

        if (mysqli_stmt_num_rows($sentencia) > 0) {
            header ("location:Admin/index.html");
        } else {
            header ("location:e.html");
        }

        mysqli_stmt_close($sentencia);

    } elseif ($_POST['accion'] == "Registrar Ficha") {

    // Validar Registro
        $consulta = "SELECT * FROM fichas WHERE numero_ficha = ?";
        $sentencia = mysqli_prepare($getconex, $consulta);
        mysqli_stmt_bind_param($sentencia, "s", $numero_ficha);
        mysqli_stmt_execute($sentencia);
        mysqli_stmt_store_result($sentencia);

        if (mysqli_stmt_num_rows($sentencia) > 0) {
            echo "<script> alert('El número de ficha ya está registrado.'); location.href='../index.php'; </script>";
        } else {
            $query = "INSERT INTO fichas (numero_ficha, contraseña_ficha) VALUES (?, ?)";
            $sentencia_insert = mysqli_prepare($getconex, $query);
            mysqli_stmt_bind_param($sentencia_insert, "ss", $numero_ficha, $contraseña_ficha);
            mysqli_stmt_execute($sentencia_insert);

            if (mysqli_stmt_affected_rows($sentencia_insert) == 1) {
                echo "<script> alert('Ficha registrada con éxito.'); location.href='../index.php'; </script>";
            } else {
                echo "<script> alert('Error al registrar la ficha.'); location.href='../index.php'; </script>";
            }

            mysqli_stmt_close($sentencia_insert);
        }

        mysqli_stmt_close($sentencia);
    }

    mysqli_close($getconex);
}
?>
