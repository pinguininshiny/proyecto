<?php
include("conexion.php");
$getmysql = new mysqlconex();
$getconex = $getmysql->conex();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_instructor = $_POST["nombre_instructor"];
    $numero_documento = $_POST["numero_documento"];
    $contraseña_instructor = $_POST["contraseña_instructor"];

    // Validación en PHP para asegurarse de que los campos no están vacíos
    if (empty($nombre_instructor) || empty($numero_documento) || empty($contraseña_instructor)) {
        echo "<script> alert('Por favor, completa todos los campos.'); location.href='../registro.php'; </script>";
        exit();
    }
    
   // Consulta para verificar si ya existe el número de ficha
   $consulta = "SELECT * FROM instructor WHERE nombre_instructor = ?";
   $sentencia = mysqli_prepare($getconex, $consulta);
   mysqli_stmt_bind_param($sentencia, "s", $nombre_instructor);
   mysqli_stmt_execute($sentencia);
   mysqli_stmt_store_result($sentencia);
   
   // Verificar qué botón fue presionado
   if ($_POST['accion'] == "Iniciar Sesión") {

  // Validar Inicio de sesion
       $consulta = "SELECT * FROM instructor WHERE nombre_instructor = ? AND numero_documento = ? AND contraseña_instructor = ?";
       $sentencia = mysqli_prepare($getconex, $consulta);
       mysqli_stmt_bind_param($sentencia, "sss", $nombre_instructor, $numero_documento, $contraseña_instructor);
       mysqli_stmt_execute($sentencia);
       mysqli_stmt_store_result($sentencia);

       if (mysqli_stmt_num_rows($sentencia) > 0) {
           header ("location:Admin/index.html");
       } else {
           header ("location:e.html");
       }

       mysqli_stmt_close($sentencia);

   } elseif ($_POST['accion'] == "Registrar Instructor") {

   // Validar Registro
       $consulta = "SELECT * FROM instructor WHERE nombre_instructor = ?";
       $sentencia = mysqli_prepare($getconex, $consulta);
       mysqli_stmt_bind_param($sentencia, "s", $nombre_instructor);
       mysqli_stmt_execute($sentencia);
       mysqli_stmt_store_result($sentencia);

       if (mysqli_stmt_num_rows($sentencia) > 0) {
           echo "<script> alert('El nombre del instructor ya esta en uso'); location.href='../index.php'; </script>";
       } else {
           $query = "INSERT INTO instructor (nombre_instructor, numero_documento, contraseña_instructor) VALUES (?, ?, ?)";
           $sentencia_insert = mysqli_prepare($getconex, $query);
           mysqli_stmt_bind_param($sentencia_insert, "sss", $nombre_instructor, $numero_documento, $contraseña_instructor);
           mysqli_stmt_execute($sentencia_insert);

           if (mysqli_stmt_affected_rows($sentencia_insert) == 1) {
               echo "<script> alert('instructor registrado con éxito.'); location.href='../index.php'; </script>";
           } else {
               echo "<script> alert('Error al registrar el instructor.'); location.href='../index.php'; </script>";
           }

           mysqli_stmt_close($sentencia_insert);
       }

       mysqli_stmt_close($sentencia);
   }

   mysqli_close($getconex);
}
?>