// Obtener el contenido del div con id 'FormularioAprendices'
var DivFichas = document.getElementById('FormularioAprendices').innerHTML;
var DivInstructores = document.getElementById('FormularioInstructores').innerHTML;
var DivAdministradores = document.getElementById('FormularioAdministradores').innerHTML;

    function cambiarContenido() {
        // Cambiar el contenido del primer div
        document.getElementById('Formularios').innerHTML = DivFichas;
    }

    function cambiarContenido2() {
            // Cambiar el contenido del primer div
            document.getElementById('Formularios').innerHTML = DivInstructores;
        }

    function cambiarContenido3() {
        // Cambiar el contenido del primer div
        document.getElementById('Formularios').innerHTML = DivAdministradores;
    }